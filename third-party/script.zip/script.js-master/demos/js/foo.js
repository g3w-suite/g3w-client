console.log('hello from foo! defining dependent vars...');
var bar = 'bar';
var baz = 'baz';